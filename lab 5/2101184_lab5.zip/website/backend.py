from flask import Flask, request, jsonify
import mysql.connector
import flask_cors
app = Flask(__name__)
flask_cors.CORS(app)
# MySQL database configuration
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="B5481zrd09F$",
    database="cclab5"
)

@app.route("/feedback.html", methods=['POST'])
def submit_feedback():
    try:
        # Get the feedback data from the request
        data = request.json

        # Extract values from the data
        stars = data['stars']
        category = data['category']
        feedback_text = data['feedbackText']

        # Insert the data into the database
        cursor = db.cursor()
        query = "INSERT INTO feedback (stars, category, feedbackText) VALUES (%s, %s, %s)"
        values = (stars, category, feedback_text)
        cursor.execute(query, values)
        db.commit()
        cursor.close()

        return jsonify({"success": True, "message": "Feedback submitted successfully"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
